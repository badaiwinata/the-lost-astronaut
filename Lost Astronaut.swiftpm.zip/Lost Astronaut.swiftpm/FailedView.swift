import SwiftUI

struct FailedView: View {
    @Environment(\.presentationMode) var presentation
    @State private var yOffset: CGFloat = 0
    
    var body: some View {
        ZStack {
            //App BG
            Color (red:0.09, green: 0.05, blue: 0.1)
            .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
            
            //Content
            ZStack {
                Image("RedLost")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 550, height: 550, alignment: .center)
                
                VStack {
                    Image("FloatingAstro")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 100, alignment: .center)
                        .offset(y: yOffset)
                        .onAppear {
                            withAnimation(Animation.linear(duration: 1.0).repeatForever()) {
                                yOffset = 15
                            }
                        }
                    
                    Text("Time's up! Unfortunately, you gave the wrong direction and the Astronaut got lost.")
                        .font(.title3)
                        .multilineTextAlignment(.center)
                        .padding()
                        .frame(width: 450)
                    
                    
                    Button(action: {
                        self.presentation.wrappedValue.dismiss()
                    }) {
                        Text("Done")
                            .frame(width:100)
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(8)
                    }
                }
                

            }
            
        }
    }
}

struct FailedView_Previews: PreviewProvider {
    static var previews: some View {
        FailedView()
    }
}
