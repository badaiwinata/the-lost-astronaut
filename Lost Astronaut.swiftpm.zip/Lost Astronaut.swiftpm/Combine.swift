import SwiftUI
import Combine

let changeSceneEvent = PassthroughSubject<String, Never>()
