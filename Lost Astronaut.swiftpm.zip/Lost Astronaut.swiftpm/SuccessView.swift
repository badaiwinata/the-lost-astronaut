import SwiftUI

struct SuccessView: View {
    @Environment(\.presentationMode) var presentation
    @State private var xOffset: CGFloat = 0
    
    var body: some View {
        ZStack {
            //App BG
            Image("BackgroundImageApp")
                .resizable()
                .scaledToFill()
                .ignoresSafeArea()
            
            // Content
            VStack {
                Image("DrivingAstro")
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                    .frame(width: 220, alignment: .center)
                    .offset(x: xOffset)
                    .onAppear {
                        withAnimation(Animation.linear(duration: 1.0).repeatForever()) {
                            xOffset = 10
                        }
                    }
                
                Text("Congratulation! You managed to help the Astronaut back to Earth safely")
                    .font(.title3)
                    .multilineTextAlignment(.center)
                    .padding()
                    .frame(width: 450)
                
                Button(action: {
                    self.presentation.wrappedValue.dismiss()
                }) {
                    Text("Done")
                        .frame(width:100)
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(8)
                }
            }
            //Earth BG
            ZStack {
                    Text("🌍")
                        .font(.system(size: 400))
                        .offset(x: 1, y:400)
                        .ignoresSafeArea()
            }
        }
    }
}

struct SuccessView_Previews: PreviewProvider {
    static var previews: some View {
        SuccessView()
    }
}
