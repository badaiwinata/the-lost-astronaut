import SwiftUI

// Starting Page
struct ContentView: View {
    @State private var yOffset: CGFloat = 0
    
    var body: some View {
        NavigationView {
            ZStack {
                // App BG
                Image("BackgroundImageApp")
                    .resizable()
                    .scaledToFill()
                    .ignoresSafeArea()
                
                // Main Content
                VStack {
                    Image("LostAstro")
                        .resizable()
                        .aspectRatio(contentMode: .fit)
                        .frame(width: 500, height: 500, alignment: .center)
                        .offset(y: yOffset)
                        .onAppear {
                            withAnimation(Animation.linear(duration: 1.5).repeatForever()) {
                                yOffset = 10
                            }
                        }
                    
                    Text("Help navigate the lost Astronaut back to Earth!")
                        .font(.title2)
                        .multilineTextAlignment(.center)
                        .padding()
                        .frame(width: 450, alignment: /*@START_MENU_TOKEN@*/.center/*@END_MENU_TOKEN@*/)
                    
                    NavigationLink(destination: GameDragAndDropView()){
                        Text("Let's Go!")
                            .frame(width:100)
                            .fontWeight(.medium)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(8)
                    }
                }
            }
        }
        .navigationViewStyle(.stack)
    }
}
