import SwiftUI

let north = "NORTH"
let south = "SOUTH"
let west = "WEST"
let east = "EAST"
let northEast = "NORTH EAST"
let northWest = "NORTH WEST"
let southEast = "SOUTH EAST"
let southWest = "SOUTH WEST"

struct GameDragAndDropView: View {
    @State var activeView = "Drag and Drop"
    var body: some View {
        VStack {
            if activeView == "Drag and Drop" {
                DragAndDropView ()
            }
            if activeView == "Success" {
                SuccessView ()
            }
            if activeView == "Failed"{
                FailedView ()
            }
        }
        .onReceive(changeSceneEvent, perform: { newActiveView in
            activeView = newActiveView
        })
    }
}

struct DragAndDropView: View {
    @Environment(\.presentationMode) var presentation
    
    @State var offset: CGSize = .zero
    @State var compassDirection = ""
    @State var point = 0
    @State var isGameStart = false
    @State private var timeRemaining = 60
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State var isRightAlert = false
    @State var isWrongAlert = false
    @State var alertDuration = 0
    
    //random word appear
    func randomCompassDirection () {
        let directionList = [north, south, east, west, northEast, northWest, southEast, southWest]
        compassDirection = directionList.randomElement()!
    }
    
    var body: some View {
        GeometryReader {geometry in
            ZStack{
                //App BG
                Color (red:0.09, green: 0.05, blue: 0.1)
                    .edgesIgnoringSafeArea(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                
                Image("BackgroundStar")
                    .resizable()
                    .scaledToFit()
                    .ignoresSafeArea()
                
                if isGameStart {
                    //Game Bar
                    ZStack{
                        VStack {
                            ZStack {
                                Image("CompassArrow")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 300, alignment: .center)
                                
                                Image("DrivingAstro")
                                    .resizable()
                                    .aspectRatio(contentMode: .fit)
                                    .frame(width: 150, alignment: .center)
                                
                                VStack {
                                    Spacer()
                                        .frame(height: 40)
                                    HStack {
                                        Button("Pause / Hint"){
                                            isGameStart = false
                                        }
                                        .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                                        .font(.title3)
                                        
                                        Text("\(point) / 1500")
                                        .font(.title3)
                                        Text("AU")
                                        .font(.title3)
                                        
                                        Text("Time: \(timeRemaining)")
                                            .font(.title3)
                                            .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                                            .foregroundColor(Color.white)
                                            .background(Color.orange)
                                            .cornerRadius(8)
                                    }
                                    Spacer()
                                }
                                
                                VStack {
                                    Spacer()
                                    if isGameStart == true && isRightAlert {
                                        Text("Good Job!")
                                            .font(.title3)
                                    }
                                    if isGameStart == true && isWrongAlert {
                                        Text("Wrong Direction!")
                                            .font(.title3)
                                    }
                                    Spacer()
                                        .frame(height: 150)
                                }
                                
                                Text(compassDirection)
                                    .font(.title3)
                                    .padding(.horizontal, 16)
                                    .frame(height: 44)
                                    .foregroundColor(Color.white)
                                    .background(Color.orange)
                                    .cornerRadius(25)
                                    .padding(/*@START_MENU_TOKEN@*/.all/*@END_MENU_TOKEN@*/)
                                    .offset(offset)
                                    .gesture( // untuk deteksi Gesture
                                        DragGesture() // untuk Gesture yg DRAG
                                            .onChanged{ gesture in 
                                                guard isGameStart else {return}
                                                // code dijalankan ketika
                                                // ada gesture drag dari user
                                                offset = gesture.translation 
                                                // gesture.transalation utk dapetin pergerakan dari titik awal
                                            }
                                            .onEnded{ _ in 
                                                // ini code dijalankan ketika
                                                // user sudah tdk lagi DRAG (lepas drag)
                                                let x = offset.width
                                                let y = offset.height
                                                let isSouth = y > 120
                                                let isNorth = y < -120
                                                let isEast = x > 120
                                                let isWest = x < -120
                                                
                                                //get user answer
                                                var userAnswer = ""
                                                if isNorth && isEast {
                                                    userAnswer = northEast
                                                }else if isNorth && isWest{
                                                    userAnswer = northWest
                                                }else if isSouth && isEast {
                                                    userAnswer = southEast
                                                }else if isSouth && isWest {
                                                    userAnswer = southWest
                                                }else if isNorth {
                                                    userAnswer = north
                                                }else if isSouth {
                                                    userAnswer = south
                                                }else if isWest {
                                                    userAnswer = west
                                                }else if isEast {
                                                    userAnswer = east
                                                }
                                                if !userAnswer.isEmpty {
                                                    if userAnswer==compassDirection{
                                                        point += 100
                                                        isRightAlert = true
                                                        isWrongAlert = false
                                                    } else {
                                                        isRightAlert = false
                                                        isWrongAlert = true
                                                    }
                                                    if point == 1500 {
                                                        //Move to succes page
                                                        changeSceneEvent.send("Success")
                                                    }
                                                    alertDuration = 2
                                                    randomCompassDirection()
                                                }
                                                print("user answer", userAnswer)
                                                
                                                offset = .zero
                                            }
                                    )
                            }
                            
                            //Pause/Hint Modal
                            if isGameStart == false {
                                
                            }
                        }  
                    }
                   
                } else {
                    VStack {
                        //Compass Top
                        HStack{
                            Label("North West", systemImage: "arrow.up.backward")
                                .font(.title3)
                            Spacer()
                                .frame(width: 20)
                            Label("North", systemImage: "arrow.up")
                                .font(.title3)
                            Spacer()
                                .frame(width: 20)
                            Label("North East", systemImage: "arrow.up.forward")
                                .font(.title3)
                        }
                        Spacer()
                            .frame(height: 28)
                        
                        //Compass Mid
                        HStack{
                            Label("West", systemImage: "arrow.backward")
                                .font(.title3)
                            Spacer()
                                .frame(width: 36)
                            Image("DrivingAstro")
                                .resizable()
                                .aspectRatio(contentMode: .fit)
                                .frame(width: 150, height: 150, alignment: .center)
                            Spacer()
                                .frame(width: 36)
                            Label("East", systemImage: "arrow.forward")
                                .font(.title3)
                        }
                        Spacer()
                            .frame(height: 28)
                        
                        //Compass Bottom
                        HStack{
                            Label("South West", systemImage: "arrow.down.backward")
                                .font(.title3)
                            Spacer()
                                .frame(width: 20)
                            Label("South", systemImage: "arrow.down")
                                .font(.title3)
                            Spacer()
                                .frame(width: 20)
                            Label("South East", systemImage: "arrow.down.forward")
                                .font(.title3)
                        }
                        
                        Spacer()
                            .frame(height: 60)
                        
                        //How to play
                        VStack {
                            Text("How to play :")
                                .font(.body)
                            Text("Drag each word that appears to the right direction")
                                .font(.headline)
                                .multilineTextAlignment(.center)
                                .frame(width: 450)
                        }
                        .padding()
                        .border(Color.white, width: 1)
                        
                        Spacer()
                            .frame(height: 60)
                        
                        Button ("Start Navigate!") {
                            isGameStart = true
                        }
                        .frame(width:140)
                        .fontWeight(.medium)
                        .foregroundColor(.white)
                        .padding()
                        .background(Color.blue)
                        .cornerRadius(8)
                        
                        Button(action: {
                            self.presentation.wrappedValue.dismiss()
                        }) {
                            Text("Home")
                                .font(.body)
                                .padding()
                        }
                    }
                    .padding(100)
                    .background(Color.black.opacity(0.8))
                    .cornerRadius(25)
                }
                
            }
            .frame (minWidth: 0, maxWidth: .infinity, minHeight: 0, maxHeight: .infinity, alignment: .center)
        }
        
        .onAppear(perform: {
            randomCompassDirection()
        })
        .onReceive(timer) { time in
            guard isGameStart else { return }
            if timeRemaining == 0 {
                changeSceneEvent.send("Failed")
                isGameStart = false
            }
            if timeRemaining > 0 {
                timeRemaining -= 1
            }
            alertDuration -= 1
            if alertDuration == 0 {
                isRightAlert = false
                isWrongAlert = false
            }
        }
    }
}

struct DragAndDropView_Previews: PreviewProvider {
    static var previews: some View {
        GameDragAndDropView()
    }
}

